<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use App\Mail\TwoFactorCodeMail;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;
use App\Http\Requests\Auth\LoginRequest;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): View
    {
        return view('auth.login');
    }

    /**
     * Handle an incoming authentication request.
     * @throws ValidationException
     */
    public function store(LoginRequest $request): RedirectResponse
    {
        $request->authenticate();
        $user = Auth::user();

        // Log that we're starting
        Log::info('=== 2FA Process Started ===');
        Log::info('User email: ' . $user->email);

        // Generate 2FA code
        $code = rand(100000, 999999);
        Log::info('Generated code: ' . $code);

        // Save to database
        $user->two_factor_code = $code;
        $user->two_factor_expires_at = now()->addMinutes(10);
        $user->save();
        Log::info('Code saved to database');

        // Try to send email
        Log::info('Attempting to send email to: ' . $user->email);

        try {
            Mail::to($user->email)->send(new TwoFactorCodeMail($code));
            Log::info('✅ Email sent successfully!');
        } catch (Exception $e) {
            Log::error('❌ Email FAILED: ' . $e->getMessage());
            Log::error('Exception: ' . $e);
        }

        Log::info('=== Redirecting to 2FA page ===');

        return redirect()->route('2fa.show');
    }
    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect('/');
    }
}
