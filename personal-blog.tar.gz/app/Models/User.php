<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     *
     */
    public string $email;
    public ?string $two_factor_code;
    public ?string $two_factor_expires_at;
    protected $fillable = [
        'name',
        'email',
        'password',
        'two_factor_code',
        'two_factor_expires_at',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }

    // A user has many posts
    public function posts(): HasMany
    {
        return $this->hasMany(Post::class);
    }

//    public function generateTwoFactorCode()
//    {
//        $this->two_factor_code = rand(100000, 999999); // 6-digit code
//        $this->two_factor_expires_at = now()->addMinutes(10);
//        $this->save(); // eloquent orm method that tells laravel to persist any changes made to the model back into the database.
//    }

//    public function resetTwoFactorCode()
//    {
//        $this->two_factor_code = null;
//        $this->two_factor_expires_at = null;
//        $this->save();
//    }
}
