@extends('layouts.public')
@section('title', $post->title)
@section('content')
    <!-- Single Post View (Public) -->
<article class="max-w-4xl mx-auto">
    <!--Post Header-->
    <header class="mb-8">
        <h1 class="text-4xl font-bold text-gray-900 mb-4">{{$post->title}}</h1>

        <div class="flex items-center text-sm text-gray-600 mb-4">
            <span>By {{$post->user->name}}</span>
            <span class="mx-2">•</span>
            <span>{{$post->published_at->format('F d, Y')}}</span>
            @if($post->category)
                <span class="mx-2">•</span>
                <a href="{{route('categories.show', $post->category->slug)}}" class="text-indigo-600 hover:text-indigo-800">
                    {{$post->category->name}}
                </a>
                @endif
        </div>

        @if($post->tags->count() > 0)
            <div class="flex flex-wrap gap-2">
                @foreach($post->tags as $tag)
                <a href="{{route('tags.show', $tag->slug)}}" class="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-300">
                    <!-- Displays clickable tags (like #Laravel, #PHP)-->
                    #{{$tag->name}}
                </a>
                @endforeach
            </div>
            @endif
    </header>

    <!-- Post Content -->
    <div class="prose prose-lg max-w-none mb-12">
        {!! \Illuminate\Support\Str::markdown($post->content) !!}
        <!-- Converts the post's content(written in Markdown) into HTMl.
        Problem Solved: Authors can write in simple Markdown, but readers can see nicely formatted text.
-->
    </div>

    <hr class="my-12">

    <!-- Comments Section -->
    <section class="mb-12">
        <h2 class="text-2xl font-bold text-gray-900 mb-6">
            Comments({{$post->approvedComments->count()}}
        </h2>

    <!-- Comment Form -->
        <div class="bg-gray-50 p-6 rounded-lg mb-8">
            <h3 class="text-lg font-semibold mb-4">Leave a Comment</h3>

        @if(session('success'))
            <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                {{session('success')}}
            </div>
        @endif

        <form action="{{route('comments.store' , $post)}}" method="POST">
            @csrf

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
        <div>
            <label for="name" class="block text-sm font-medium text-gray-700 mb-2">Name *</label>
            <input type="text" name="name" id="name" value="{{old('name')}}" required
                   class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            @error('name')
            <p class="text-red-500 text-sm mt-m1">{{$message}}</p>
            @enderror
        </div>

        <div>
            <label for="email" class="block text-sm font-medium text-gray-700 mb-2">Email *</label>
            <input type="email" name="email" id="email" value="{{old('email')}}" required
                   class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
            @error('email')
            <p class="text-red-500 text-sm mt-1">{{$message}}</p>
            @enderror
        </div>

        <div class="mb-4">
            <label for="content" class="block text-sm font-medium text-gray-700 mb-2">Comment *</label>
            <textarea name="content" id="content" rows="4" required
                      class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-500 focus:ring-indigo-500">{{old('content')}}</textarea>
            @error('content')
            <p class="text-red-500 text-sm mt-m1">{{ $message }}</p>
            @enderror
        </div>

        <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700">
            Post Comment
        </button>
        </div>


    <!-- Display Comments -->
        @if($post->approvedComments->count() > 0)
            <div class="space-y-6">
                @foreach($post->approvedComments as $comment)
                    <div class="bg-white p-6 rounded-lg shadow">
                        <div class="flex items-center mb-2">
                            <div class="font=semibold text-gray-900">{{$comment->name}}</div>
                            <span class="mx-2 text-gray-400">•</span>
                            <div class="text-sm text-gray-600">{{$comment->created_at->diffForHumans()}}</div>
                            <!--diffforhmns() is a Laravel Carbon Method(Carbon is the date/time library Laravel uses), it takes a date/time and converts into human-friendly string -->
                        </div>
                        <p class="text-gray-700">{{$comment->content}}</p>
                    </div>
                @endforeach
            </div>
        @else
            <p class="text-gray-500 text-center py-8">No comments yet. Be the first to comment!</p>
        @endif
    </section>
</article>
    @endsection






























