<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Homepage (Welcome Page) of blog. -->
    <div class="mb-12 text-center">
        <h1 class="text-5xl font-bold text-gray-900 mb-4">Welcome to My Blog</h1>
        <p class="text-xl text-gray-600">Sharing thoughts, ideas, and stories</p>
    </div>

    <?php if($posts->count() > 0): ?>
        <div class="grid gap-8">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition">
                    <div class="p-8">
                        <h2 class="text-3xl font-bold text-gray-900 mb-3">
                            <a href="<?php echo e(route('posts.public.show', $post->slug)); ?>" class="hover:text-indigo-600">
                                <?php echo e($post->title); ?>

                            </a>
                        </h2>

                        <div class="flex items-center text-sm text-gray-600 mb-4">
                            <span><?php echo e($post->user->name); ?></span>
                            <span class="mx-2">•</span>
                            <span><?php echo e($post->published_at->format('F d, Y')); ?></span>
                            <?php if($post->category): ?>
                                <span class="mx-2">•</span>
                                <a href="<?php echo e(route('categories.show', $post->category->slug)); ?>" class="text-indigo-600 hover:text-indigo-800">
                                    <?php echo e($post->category->name); ?>

                                </a>
                                <?php endif; ?>
                        </div>

                        <?php if($post->excerpt): ?>
                            <p class="text-gray-700 text-lg mb-4"><?php echo e($post->excerpt); ?></p>
                            <?php else: ?>
                            <p class="text-gray-700 text-lg mb-4"><?php echo e(Str::limit(strip_tags($post->content), 200)); ?></p>
                        <?php endif; ?>

                        <?php if($post->tags->count() > 0): ?>
                            <div class="flex flex-wrap gap-2 mb-4">
                                <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(route('tags.show', $tag->slug)); ?>" class="bg-gray-200 text-gray-700 px-3 py-1 rounded-full text-sm hover:bg-gray-300">
                                        #<?php echo e($tag->name); ?>

                                    </a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                        <a href="<?php echo e(route('posts.public.show', $post->slug)); ?>" class="text-indigo-600 hover:text-indigo-800 font-medium text-lg">
                            Read more →
                        </a>
                    </div>
                </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-8">
            <?php echo e($posts->links()); ?>

        </div>
    <?php else: ?>

        <div class="text-center py-20">
            <p class="text-gray-500 text-xl">No posts yet. Check back soon!</p>
        </div>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>

























<?php echo $__env->make('layouts.public', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>