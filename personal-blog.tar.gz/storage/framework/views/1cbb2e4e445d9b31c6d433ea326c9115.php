<?php $__env->startSection('title', 'Manage Comments'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Admin dashboard page for managing comments -->
    <div class="bg-white shadow rounded-lg">
        <div class="p-6 border-b">
            <h2 class="text-2xl font-bold text-gray-800">Manage Comments</h2>
        </div>

        <div class="p-6">
            <?php if($comments->count() > 0): ?>
                <div class="space-y-4">
                    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="border rounded-lg p-4 <?php echo e($comment->approved ? 'bg-white' : 'bg-yellow-50'); ?>">
                            <div class="flex justify-between items-start mb-2">
                                <div>
                                    <span class="font-semibold text-gray-900"><?php echo e($comment->name); ?></span>
                                    <span class="text-gray-600 text-sm ml-2">(<?php echo e($comment->email); ?>)</span>
                                    <?php if(!$comment->approved): ?>
                                        <span class="ml-2 bg-yellow-200 text-yellow-800 px-2 py-1 rounded text-xs">Pending</span>
                                    <?php endif; ?>
                                </div>
                                <span class="text-sm text-gray-500"><?php echo e($comment->created_at->diffForHumans()); ?></span>
                            </div>

                            <p class="text-gray-700 mb-2"><?php echo e($comment->content); ?></p>

                            <div class="text-sm text-gray-600 mb-3">
                                On post: <a href="<?php echo e(route('posts.public.show', $comment->post->slug)); ?>" class="text-indigo-600 hover:underline" target="_blank"><?php echo e($comment->post->title); ?></a>
                            </div>

                            <div class="flex-space-x-3">
                                <?php if(!$comment->approved): ?>
                                    <form action="<?php echo e(route('comments.approve', $comment)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                    <button type="submit" class="text-green-600 hover:text-green-800 text-sm font-medium">
                                        Approve
                                    </button>
                                    </form>
                                    <?php endif; ?>
                            <form action="<?php echo e(route('comments.destroy', $comment)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:text-red-800 text-sm font-medium" onclick="return confirm('Delete this comment?')">
                                Delete
                            </button>
                            </form>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="mt-6">
                    <?php echo e($comments->links()); ?>

                </div>
                <?php else: ?>
                    <p class="text-gray-500 text-center py-8">No comments yet.</p>
                <?php endif; ?>
        </div>
    </div>
    <?php $__env->stopSection(); ?>























<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/comments/index.blade.php ENDPATH**/ ?>