<?php $__env->startSection('title', 'Manage Categories'); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white shadow rounded-lg">
    <div class="p-6 border-b">
        <div class="flex justify-between items-center">
            <h2 class="text-2xl font-bold text-gray-800">Manage Categories</h2>
            <a href="<?php echo e(route('categories.create')); ?>" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                Add Category
            </a>
        </div>
    </div>

    <div class="p-6">
        <?php if($categories->count() > 0): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="border rounded-lg p-6 hover:shadow-lg transition">
                        <h3 class="text-xl font-semibold text-gray-800 mb-2"><?php echo e($category->name); ?></h3>
                        <p class="text-gray-600 text-sm mb-4"><?php echo e($category->post_count); ?>

                        <?php if($category->description): ?>
                            <p class="text-gray-500 text-sm mb-4"><?php echo e($category->description); ?></p>
                        <?php endif; ?>
                        <div class="flex space-x-3">
                            <a href="<?php echo e(route('categories.edit', $category)); ?>" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">
                                Edit
                            </a>
                            <form action="<?php echo e(route('categories.destroy', $category)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-800 text-sm font-medium" onclick="return confirm('Delete this category?')">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php else: ?>
            <p class="text-gray-500 text-center py-8">No categories yet, Create your first category!</p>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>




























<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/categories/index.blade.php ENDPATH**/ ?>