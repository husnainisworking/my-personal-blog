<p>Your two-factor authentication code is: <strong><?php echo e($twoFactorCode); ?></strong></p>
<p>This code will expire in 10 minutes.</p>
<?php /**PATH /var/www/html/resources/views/emails/two_factor_code.blade.php ENDPATH**/ ?>