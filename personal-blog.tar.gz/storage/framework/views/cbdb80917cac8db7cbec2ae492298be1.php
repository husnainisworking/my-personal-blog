<?php $__env->startSection('title', 'Manage Tags'); ?>

<?php $__env->startSection('content'); ?>

    <div class="bg-white shadow rounded-lg">
    <div class="p-6 border-b">
        <div class="flex justify-between items-center">
        <h2 class="text-2xl font-bold text-gray-800">Manage Tags</h2>
            <a href="<?php echo e(route('tags.create')); ?>" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700">
                Add Tag
            </a>
        </div>
    </div>

    <div class="p-6">
        <?php if($tags->count() > 0): ?>
            <div class="flex flex-wrap gap-4">
                <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-gray rounded-lg px-4 py-3 flex items-center space-x-3">
                        <div>
                            <span class="font-semibold text-gray-800">#<?php echo e($tag->name); ?></span>
                            <span class="text-gray-600 text-sm ml-2">(<?php echo e($tag->posts_count); ?>)</span>
                        </div>
                        <div class="flex space-x-2">
                            <a href="<?php echo e(route('tags.edit', $tag)); ?>" class="text-indigo-600 hover:text-indigo-800 text-sm">
                                Edit
                            </a>
                            <form action="<?php echo e(route('tags.destroy', $tag)); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="text-red-600 hover:text-red-800 text-sm" onclick="return confirm('Delete this tag?')">
                                    Delete
                                </button>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php else: ?>
                <p class="text-gray-500 text-center py-8">No tags yet. Create your first tag!</p>
            <?php endif; ?>
    </div>
    </div>
    <?php $__env->stopSection(); ?>
























<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/tags/index.blade.php ENDPATH**/ ?>